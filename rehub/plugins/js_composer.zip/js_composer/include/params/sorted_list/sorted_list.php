<?php
/**
 * @param $settings
 * @param $value
 *
 * @since 4.2
 * @return string
 */