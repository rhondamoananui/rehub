<div>
<a href="<?php echo rehub_create_affiliate_link();?>" target="_blank" rel="nofollow">
<?php the_title();?>                                  
</a>
</div>