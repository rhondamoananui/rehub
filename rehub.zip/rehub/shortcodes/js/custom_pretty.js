jQuery(function($){
'use strict';	
	$(document).ready(function(){
		$("a[rel^='prettyPhoto']").prettyPhoto({social_tools:false});
	});
});